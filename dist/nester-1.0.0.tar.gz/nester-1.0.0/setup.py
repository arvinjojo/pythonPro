from distutils.core import setup

setup(
      name              = 'nester',
      version           = '1.0.0',
      py_modules        = ['nester'],
      author            = 'Arvin_Hao',
      author_email      = 'yuguangbit@163.com',
      url               = 'www.haoganlin.xyz/',
      description       = 'A simple sample of lists',
      )